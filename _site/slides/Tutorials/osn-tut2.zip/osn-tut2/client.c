#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/select.h>
#include <errno.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int sockfd;
struct sockaddr_in server_addr;

int main(int argc, char* argv[]) {
    char buffer[BUFFER_SIZE];
    char message[BUFFER_SIZE];
    char ipaddr[BUFFER_SIZE] = {0};
    
    if(argc == 2) {
        strcpy(ipaddr, argv[1]);
    } else {
        strcpy(ipaddr, "127.0.0.1");
    }
    
    fd_set read_fds;

    // Create TCP socket
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr(ipaddr);

    // Connect to server
    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server at %s:%d\n", ipaddr, PORT);
    printf("Type messages to send to server (Ctrl+C to quit):\n");

    while (1) {
        FD_ZERO(&read_fds);
        FD_SET(sockfd, &read_fds);
        FD_SET(STDIN_FILENO, &read_fds);

        int activity = select(sockfd + 1, &read_fds, NULL, NULL, NULL);

        if (activity < 0 && errno != EINTR) {
            perror("Select error");
            break;
        }

        // Check for data from server
        if (FD_ISSET(sockfd, &read_fds)) {
            int n = recv(sockfd, buffer, BUFFER_SIZE - 1, 0);
            if (n <= 0) {
                printf("Server disconnected\n");
                break;
            }
            buffer[n] = '\0';
            printf("Server: %s\n", buffer);
        }

        // Check for user input
        if (FD_ISSET(STDIN_FILENO, &read_fds)) {
            if (fgets(message, BUFFER_SIZE, stdin) != NULL) {
                // Remove newline
                message[strcspn(message, "\n")] = '\0';
                
                if (send(sockfd, message, strlen(message), 0) < 0) {
                    perror("Send failed");
                    break;
                }
            }
        }
    }

    close(sockfd);
    return 0;
}