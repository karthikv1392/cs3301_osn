#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/select.h>
#include <errno.h>

#define PORT 8080
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 10

int server_sockfd, client_sockfd;
struct sockaddr_in server_addr, client_addr;
socklen_t client_len;

int main() {
    char buffer[BUFFER_SIZE];
    char message[BUFFER_SIZE];
    fd_set read_fds;

    // Create TCP socket
    if ((server_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Set socket option to reuse address
    int opt = 1;
    if (setsockopt(server_sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("Setsockopt failed");
        close(server_sockfd);
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind the socket
    if (bind(server_sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_sockfd);
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_sockfd, MAX_CLIENTS) < 0) {
        perror("Listen failed");
        close(server_sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d...\n", PORT);
    printf("Waiting for client connection...\n");

    client_len = sizeof(client_addr);
    
    // Accept a client connection
    if ((client_sockfd = accept(server_sockfd, (struct sockaddr *)&client_addr, &client_len)) < 0) {
        perror("Accept failed");
        close(server_sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Client connected from %s:%d\n", 
           inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
    printf("Type messages to send to client (Ctrl+C to quit):\n");

    while (1) {
        FD_ZERO(&read_fds);
        FD_SET(client_sockfd, &read_fds);
        FD_SET(STDIN_FILENO, &read_fds);

        int activity = select(client_sockfd + 1, &read_fds, NULL, NULL, NULL);

        if (activity < 0 && errno != EINTR) {
            perror("Select error");
            break;
        }

        // Check for data from client
        if (FD_ISSET(client_sockfd, &read_fds)) {
            int n = recv(client_sockfd, buffer, BUFFER_SIZE - 1, 0);
            if (n <= 0) {
                printf("Client disconnected\n");
                break;
            }
            buffer[n] = '\0';
            printf("Client: %s\n", buffer);
        }

        // Check for user input
        if (FD_ISSET(STDIN_FILENO, &read_fds)) {
            if (fgets(message, BUFFER_SIZE, stdin) != NULL) {
                // Remove newline
                message[strcspn(message, "\n")] = '\0';
                
                if (send(client_sockfd, message, strlen(message), 0) < 0) {
                    perror("Send failed");
                    break;
                }
            }
        }
    }

    close(client_sockfd);
    close(server_sockfd);
    return 0;
}